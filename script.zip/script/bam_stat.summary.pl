#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;

my $dir_in = $ARGV[0];
my $output = $ARGV[1];
my %hash;
foreach my $file(glob("$dir_in/*.bam_stat.txt")){
	(my $name = basename($file)) =~ s/.bam_stat.txt//g;
	open  FIN,$file;
	while(<FIN>){
		chomp;
		if(/^Total records:\s+(\d+)/){
			$hash{$name}{total_records} = $1;
		}elsif(/Non primary hits\s+(\d+)/){
			$hash{$name}{total_reads} = $hash{$name}{total_records} - $1;
		}elsif(/Unmapped reads:\s+(\d+)/){
			my $x = $hash{$name}{total_reads}-$1;
			my $y = sprintf("%.3f", $x/$hash{$name}{total_reads}*100 );
			$hash{$name}{total_map} = "$x($y%)";
		}elsif(/mapq < mapq_cut \(non-unique\):\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{multi_map} = "$x($y%)";
		}elsif(/mapq >= mapq_cut \(unique\):\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{unique_map} = "$x($y%)";
		}elsif(/Read-1:\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{read1_map} = "$x($y%)";
		}elsif(/Read-2:\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{read2_map} = "$x($y%)";
		}elsif(/Reads map to '\+':\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{positive_map} = "$x($y%)";
		}elsif(/Reads map to '\-':\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{negative_map} = "$x($y%)";
		}elsif(/Splice reads:\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{splice_map} = "$x($y%)";
		}elsif(/Non-splice reads:\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{unsplice_map} = "$x($y%)";
		}elsif(/Reads mapped in proper pairs:\s+(\d+)/){
			my $x = $1;
			my $y = sprintf("%.3f",$x/$hash{$name}{total_reads}*100);
			$hash{$name}{proper_map} = "$x($y%)";
		}
	}
	close FIN;
}

open FOUT,">$output";
print FOUT "sample\t".join("\t",qw/total_reads total_map unique_map multi_map read1_map read2_map positive_map negative_map splice_map unsplice_map proper_map/)."\n";
foreach my $name(sort keys %hash){
	print FOUT $name;
	foreach my $x(qw/total_reads total_map unique_map multi_map read1_map read2_map positive_map negative_map splice_map unsplice_map proper_map/){
		unless (exists $hash{$name}{$x}){
			print $x,"\n";
		}
		print FOUT "\t",$hash{$name}{$x};
	}
	print FOUT "\n";
}
close FOUT;

