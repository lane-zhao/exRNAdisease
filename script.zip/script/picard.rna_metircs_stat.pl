#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;

my $dir_in = $ARGV[0];
my $output = $ARGV[1];
my %hash;
foreach my $file(glob("$dir_in/*/*.rna_metrics.tsv")){
	(my $name = basename($file)) =~ s/.rna_metrics.tsv//g;
	open  FIN,$file;
	<FIN>;<FIN>;<FIN>;<FIN>;<FIN>;<FIN>;
	my $head = <FIN>; chomp($head);
	my @header = split /\t/,$head;
	my $cont = <FIN>; chomp($cont);
	my @content = split /\t/,$cont;
	#"Coding_bases(%)", "UTR_bases(%)", "Intronic_bases(%)", "Intergenic_bases(%)", "mRNA_bases(%)"
	$hash{$name}{"Coding"}     = $content[16]*100;
	$hash{$name}{"UTR"}        = $content[17]*100;
	$hash{$name}{"Intron"}     = $content[18]*100;
	$hash{$name}{"Intergenic"} = $content[19]*100;
	close FIN;
}

open FOUT,">$output";
print FOUT "sample_id\tCoding\tUTR\tIntron\tIntergenic\n";
foreach my $name(sort keys %hash){
	print FOUT $name;
	foreach my $x(qw/Coding UTR Intron Intergenic/){
		print FOUT "\t",$hash{$name}{$x};
	}
	print FOUT "\n";
}
close FOUT;
