#!/usr/bin/perl -w
use strict;
use warnings;
use Carp;
use Bio::SearchIO;
use Getopt::Long;
use List::Util qw ( sum);
use Math::Round qw(:all);
use Config::IniFiles;

my %opts;
my $VERSION="2.0";
GetOptions( \%opts,"i=s", "s=s","o=s","maxEvalue=f","minIdentity=i","sumary!","config=s","merg=s","unmatch=s","mirna=s","pie=s", "h!");

my $usage = <<"USAGE";
       Program : $0
       Version : $VERSION
       Contact : binxu.liu\@majorbio.com
       Lastest modify:2016-09-20
       Discription:Only for singal-handed unique file of each sample output bye uniqueFastaqs.pl merged and blast to rfam
       Usage :perl $0 [options]
                -i*		blastn.out		fasta blast to rfam database output               
                -s*		rfam.seed		rfam seed file
                -o*		table.out		blast info table for all matched seqs
                -sumary					on/off for summary output
                -merg*		merge.uniq.fasta	singal-handed unique file of each sample output bye uniqueFastaqs.pl merged
                -config 	config.ini		config file for uniqueFastaqs.pl
                -maxEvalue	1e-5			Max E value 
                -minIdentity	50			Min percent(or positive) identity over the alignment
                -unmatch	unmatch.list		unmacthed to rfam  seqname list
                -mirna		mirna.list		output mirna list 	 
                -pie		pie_out			output pie chart dir,must spefict -sumary first
                -h					Display this usage information
                * 					must be given Argument
                
USAGE


die $usage if ( !( $opts{i} && $opts{s} && $opts{o} && $opts{merg}) || $opts{h} ); 
my %seed;
my $id;
open SEED, "< $opts{s}" or die "Error:Cannot open file  $opts{s} : $! \n";
while(<SEED>){
	chomp;

	if(/^#=GF\s+AC\s+(\S+)\s*$/){
		$id=$1;
	}elsif(/^#=GF\s+DE\s+(.*)\s*$/){
		$seed{$id}{DE}=$1;
		#print "$1\n";
	}elsif(/^#=GF\s+TP\s+(.*)\s*$/){
		$seed{$id}{TP}=$1;
	}
}
close SEED;
=pod
my $cfg = Config::IniFiles->new(-file => $opts{config});
my @names=$cfg->Parameters("FASTA");
my %titles;

foreach my $f (@names){
	my $name;
	if($cfg->SectionExists("NAME")&& $cfg->val('NAME',$f)){
		$name=$cfg->val('NAME',$f);
		$titles{$f}=$name;
	}else{
		$name=$f;
		$titles{$f}=$f;
	}
}
=cut
my %seqs_uniq;
my %seqs_num;
my %seqnames;

open UNIQ, "< $opts{merg}" or die "Error:Cannot open file  $opts{merg} : $! \n";
while(<UNIQ>){
	chomp;
	if(/^>(\S+)/){
		my $name =$1;
		$seqnames{$name}=1;
		#$name=~/^(\w+)\_\d+\_x(\d+)$/;
		$seqs_uniq{$1}=1;
		$seqs_num{$1}=1;
	}
}
close UNIQ;

my %sumary;
my %sample_sumary;
my %matched_names;
my @miRNAlist;
# my $searchio= Bio::SearchIO->new(-format => 'blast',
#								 -file => $opts{i},
#								 -best => 1,
#								);
#
open SEARCHIO, "< $opts{i}" or die "Error:Cannot open file  $opts{i} : $! \n";
<SEARCHIO>;

open TABLE, "> $opts{o}" or die "Error:Cannot open file  $opts{o} : $! \n";
print TABLE "query_name\tTP\tDE\tAC\tHit\tHspLength\tEvalue\tIdentity\n";
while(<SEARCHIO>){
	my @line = split(/\t/, $_);
	my $query_name = $line[5];
	my $hit_name = $line[9];
	$matched_names{$query_name}=1;
	
	$hit_name =~ /^([\w\-]+);.*/;		
	my $c = $1;
	#print $hit->name."***\n";
	print TABLE $query_name."\t".$seed{$c}{DE}."\t".$seed{$c}{TP}."\t".$c."\t".$hit_name."\t".$line[2]."\t".$line[1]."\t".$line[3]."\n";
	if($opts{sumary}){
		$sumary{uniq}{$seed{$c}{TP}}++;
		#$result->query_name =~/^(\w+)\_\d+\_x(\d+)$/;
		my $sa=$query_name;
		my $n=1;
		$sumary{total}{$seed{$c}{TP}}+=$n;
		$sample_sumary{uniq}{$sa}{$seed{$c}{TP}}++;
		$sample_sumary{total}{$sa}{$seed{$c}{TP}}+=$n;
		if($seed{$c}{TP}=~/miRNA|microRNA/i ||$seed{$c}{DE}=~/microRNA|miRNA/i){
			push(@miRNAlist,$query_name);
		}

	}
	#last;

}
close TABLE;

if($opts{sumary}){

#out all 
	open ALL, "> All_rfam_stat.xls" or die "Error:Cannot open file All_rfam_stat.xls : $! \n";
	print ALL "Type\tTotal_num\tTotal_percent\n";
	my $total_all=sum(values(%seqs_num));
	print ALL "All_reads\t$total_all\t100%\n";
	
	my $match_total_all=sum(values(%{$sumary{total}}));
	
	print ALL "All_matched\t$match_total_all\t".nearest(.01, $match_total_all/$total_all * 100)."%\n";
	my $r_out="";
	my $other=0;
	my $unmatch=$total_all-$match_total_all;
	my (@key,@values);
	system("mkdir -p $opts{pie}") if($opts{pie});
	foreach my $t (keys(%{$sumary{total}})){
		my $total_percent=nearest(.01, $sumary{total}{$t}/$total_all * 100);
		print ALL "$t\t".$sumary{total}{$t}."\t".$total_percent."%\n";
		if($sumary{total}{$t}/$total_all>=0.01){
			push(@key,'"'.$t.'"');
			push(@values,$sumary{total}{$t});
		}else{
			$other+=$sumary{total}{$t};
		}
	}
	close ALL;
	if($opts{pie}&&scalar(@key)>1){
		$r_out="library(RColorBrewer)\n";
		$r_out.="pdf(file=\"".$opts{pie}."/all_rfam.pdf"."\",width=10)\n";
		$r_out.="slices<-c(".join(",",@values).",$other,$unmatch)\n";
		$r_out.="lbls<-c(".join(",",@key).",\"Other\",\"Unmatched\")\n";
		$r_out.="pct<-round(slices/sum(slices)*100)\n";
		$r_out.="lbls<-paste(lbls,pct)\n";
		$r_out.="lbls<-paste(lbls,\"%\",sep=\"\")\n";
		$r_out.='ColorList<-brewer.pal(length(lbls),"Paired")'."\n";
		$r_out.="pie(slices,labels=lbls,col=ColorList,main=\"Pie Chart of ALL\",border=\"white\")\n";
		$r_out.="dev.off()\n";
		 open R, "> $opts{pie}/all.R" or die "Error:Cannot open file  $opts{pie}/all.R : $! \n";     
                  print R $r_out;
                close R;
                system("R --no-save <  $opts{pie}/all.R");
		
	}
	
	
#out samples
=pod
	foreach my $s (sort values(%titles)){
		open SS,">$s\_rfam_stat.xls" or die "Error:Cannot open file  $s\_rfam_stat.xls : $! \n";
		print SS "Types\tUniq_num\tUniq_percent\tTotal_num\tTotal_percent\n";
		my $total_uniq=$seqs_uniq{$s};
		my $total_all=$seqs_num{$s};
		print SS "All_reads\t$total_uniq\t100%\t$total_all\t100%\n";
		my $match_total_uniq=sum(values(%{$sample_sumary{uniq}{$s}}));
		my $match_total_all=sum(values(%{$sample_sumary{total}{$s}}));
		print SS "All_matched\t$match_total_uniq\t".nearest(.01, $match_total_uniq/$total_uniq * 100)."%\t$match_total_all\t".nearest(.01, $match_total_all/$total_all * 100)."%\n";
		foreach my $t (keys(%{$sample_sumary{uniq}{$s}})){
			my $uniq_percent=nearest(.01, $sample_sumary{uniq}{$s}{$t}/$total_uniq * 100);
			my $total_percent=nearest(.01, $sample_sumary{total}{$s}{$t}/$total_all * 100);
			print SS "$t\t".$sample_sumary{uniq}{$s}{$t}."\t".$uniq_percent."%\t".$sample_sumary{total}{$s}{$t}."\t".$total_percent."%\n";
		}
		close SS;
	}

	if($opts{pie}){
	foreach my $s (sort values(%titles)){
		undef @key;
		undef @values;
		$other=0;
		$r_out='';
		my $total_all=$seqs_num{$s};
		my $match_total_all=sum(values(%{$sample_sumary{total}{$s}}));
		$unmatch=$total_all-$match_total_all;
		foreach my $t (keys(%{$sample_sumary{total}{$s}})){
			if($sample_sumary{total}{$s}{$t}/$total_all>=0.01){
				push(@key,'"'.$t.'"');
				push(@values,$sample_sumary{total}{$s}{$t});
			}else{
				$other+=$sample_sumary{total}{$s}{$t};
			}
		}
		my $ss=$s;
		$ss=~s/\s+/_/g;
		$ss=~s/[^\w]//g;
		$r_out="library(RColorBrewer)\n";
		$r_out.="pdf(file=\"".$opts{pie}."/$ss\_rfam.pdf"."\",width=10)\n";
		$r_out.="slices<-c(".join(",",@values).",$other,$unmatch)\n";
		$r_out.="lbls<-c(".join(",",@key).",\"Other\",\"Unmatched\")\n";
		$r_out.="pct<-round(slices/sum(slices)*100)\n";
		$r_out.="lbls<-paste(lbls,pct)\n";
		$r_out.="lbls<-paste(lbls,\"%\",sep=\"\")\n";
		my $xx=$ss;
		$xx=~s/_/ /g;
		$r_out.='ColorList<-brewer.pal(length(lbls),"Paired")'."\n";
		$r_out.="pie(slices,labels=lbls,col=ColorList,main=\"Pie Chart of $xx\",border=\"white\")\n";
		$r_out.="dev.off()\n";
		open R, "> $opts{pie}/$ss.R" or die "Error:Cannot open file  $opts{pie}/$ss.R : $! \n";
		  print R $r_out;
		close R;
		system("R --no-save <  $opts{pie}/$ss.R");
	}
	}
=cut
}


if($opts{unmatch}){
	open UNMATCH, "> $opts{unmatch}" or die "Error:Cannot open file  $opts{unmatch} : $! \n";
	foreach my $s (keys(%seqnames)){
		unless(exists($matched_names{$s})){
			print UNMATCH "$s\n";
		}
	}
	close UNMATCH;
}
if($opts{mirna}){
	open MIRNA, "> $opts{mirna}" or die "Error:Cannot open file  $opts{mirna} : $! \n";
	print MIRNA join("\n",@miRNAlist)."\n";
	close MIRNA;
}
