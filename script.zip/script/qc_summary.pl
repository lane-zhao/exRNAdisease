#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;
use Getopt::Long;
use Time::Local;
my %opts;
GetOptions (\%opts,
	"rawdata=s", 
	"cleandata=s", 
	"rRNA=s",
	"output=s",
	"help!",
);

my $program = basename($0);
my $usage = <<"USAGE";
  Program : $program
  Discription: qc_summary
  Usage: perl $program [options]
    -rawdata*     rawdata.stat.xls, required
    -cleandata    cleandata.stat.xls, required
    -rRNA         rRNA.stat.xls, required
    -output       output file, required
  example:perl $0
USAGE

die $usage if ( !$opts{rawdata} || !$opts{cleandata} || !$opts{rRNA} || !$opts{output} ||$opts{help} );

my %infor;

open (FIN,"<$opts{rawdata}") || die "Can not open $opts{rawdata}\n";
<FIN>;
while(<FIN>){
	chomp;
	my ($sample, $total_reads, $total_bases) = split /\t/,$_;
	$infor{$sample}{"Raw reads"} =  $total_reads;
	$infor{$sample}{"Raw bases"} =  $total_bases;
}
close FIN;

open (FIN,"<$opts{cleandata}") || die "Can not open $opts{cleandata}\n";
<FIN>;
while(<FIN>){
	chomp;
	my ($sample, $total_reads, $total_bases, $error,  $q20, $q30, $gc) = split /\t/,$_;
	$infor{$sample}{"Clean reads"} =  $total_reads;
	$infor{$sample}{"Clean bases"} =  $total_bases;
	$infor{$sample}{"Error rate(%)"} =  $error;
	$infor{$sample}{"Q20(%)"} =  $q20;
	$infor{$sample}{"Q30(%)"} =  $q30;
	$infor{$sample}{"GC content(%)"} =  $gc;
}
close FIN;

open (FIN,"<$opts{rRNA}") || die "Can not open $opts{rRNA}\n";
<FIN>;
while(<FIN>){
	chomp;
	my ($sample, $ration) = split /\t/,$_;
	$ration =~ s/%//g;
	$infor{$sample}{"rRNA Ratio(%)"} =  $ration;
}
close FIN;

#caculate deviation
open (FOUT,">$opts{output}") || die "Can not open $opts{output} !\n";
print FOUT "sample\t".join("\t",("Raw reads", "Raw bases", "Clean reads", "Clean bases", "Error rate(%)", "Q20(%)", "Q30(%)", "GC content(%)", "rRNA Ratio(%)"))."\n";
foreach my $sample(sort keys %infor){
	print FOUT $sample;
	foreach my $x(("Raw reads", "Raw bases", "Clean reads", "Clean bases", "Error rate(%)", "Q20(%)", "Q30(%)", "GC content(%)", "rRNA Ratio(%)")){
		print FOUT "\t", $infor{$sample}{$x};
	}
	print FOUT "\n";
}
close FOUT;