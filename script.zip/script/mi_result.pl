#!/usr/bin/perl -w
#Author: Guo Yuntao
#Email: yuntao.guo@majorbio.com
#Date: 2016-03-28
my $version=1.00;

use strict;
use Getopt::Long;

my %opts;
GetOptions(\%opts,"i=s","o=s","h");
if (!(defined $opts{i} and defined $opts{o} ) || defined $opts{h}) { #necessary arguments
&usage;
}

my $filein=$opts{'i'};
my $fileout=$opts{'o'};

open IN,"<$filein"; #input file  
open OUT,">$fileout"; #output file  
print OUT "miRNA\tTarget_transcript\tScore\tEnergy\n";
while (<IN>) {
	if(/>>/){
		my @s=split /\t/;
		$s[0] =~s/^>>//;
	#	$s[-1]=~s/\s+/,/g;
	#	$s[-1]=~s/^,//g;
	#	$s[-1]=~s/,$//g;
		print OUT "$s[0]\t$s[1]\t$s[4]\t$s[5]\n";
	}
}

close IN;
close OUT;
sub usage{
print <<"USAGE";
Version $version
Usage:
	$0 -i <miranda_out> -o <result.xls>
options:
	-i input file
	-o output file
	-h help
USAGE
exit(1);
}

