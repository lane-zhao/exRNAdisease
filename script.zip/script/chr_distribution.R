args = commandArgs(trailingOnly=T)
library(ggplot2)

data<-read.table(args[1],header=T,sep="\t")
pdf(args[2])
ggplot(data=data,mapping=aes(x=chromosome,y=circRNA_number,fill=chromosome,group=factor(1)))+theme(axis.text.x=element_text(angle=45,size=8)) + geom_bar(stat="identity")
dev.off()


