#!/usr/bin/env perl
use strict;
use warnings;
use List::Util qw/sum max min/;
use Getopt::Long;
use Cwd;
use FindBin;
use File::Basename;
use Data::Dumper;
use Parallel::ForkManager;

my $help;
my $cleandata;
my $outfile;

&GetOptions(
	'help!'        => \$help,
	'cleandata=s'  => \$cleandata,
	'outfile=s'    => \$outfile,
);

if ($help) {
    &usage;
}

$outfile ||= "res.txt";

unless($clean) {
	print STDERR "Error: -clean must be specified ! \n";
	&usage;
}

my $numb_sn;
my @array_reads;
my @array_bases;
my @array_q30;
my @array_gc;

open FIN,"$cleandata" or die "can not open clean data statistics file[$cleandata]";
my $head = <FIN>; chomp($head);
my @header = split /\t/,$head;
while(<FIN>){
	chomp;
	my ($sn,$reads,$bases,$error,$q20,$q30,$gc) = split /\t/,$_;
	$numb_sn++;
	push @array_reads,$reads;
	push @array_bases,$bases;
	push @array_q30,$q30;
	push @array_gc,$gc;
}
close FIN;

my $total_bases = sprintf("%.3f", sum(@array_bases)/1024/1024/1024);
my $mean_bases  = sprintf("%.3f", sum(@array_bases)/1024/1024/1024/$numb_sn);
my $min_q30 = min(@array_q30);
my $min_gc  = min(@array_gc);
my $max_gc  = max(@array_gc);

open  FOUT,">$outfile" or die "can not open $outfile ! \n";
print FOUT "完成 $numb_sn 个样品的转录组分析，共获得 $total_bases Gb Clean Data，各样品Clean Data均达到 $mean_bases Gb，Q30碱基百分比在 $min_q30 %以上, GC含量在 $min_gc\%到 $max_gc\%之间\n";
close FOUT;

sub usage{
	my $s = basename($0);
	die(qq/
usage: perl $s -head 1 -outfile result.txtx file-1 file-2 file-3
#################################################################################################
#  Required:
#
#  --cleandata  <string>         clean fastq data statistics ! [required]
#
#  --outfile    <string>         output file
#
#  --help       <null>           help information
###############################################################################################
\n/);
}
