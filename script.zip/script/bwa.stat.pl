#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;

my $dir_in = $ARGV[0];
my $output = $ARGV[1];
my %hash;
foreach my $file(glob("$dir_in/*.stat")){
	(my $name = basename($file)) =~ s/.stat//g;
	open  FIN,$file;
	while(<FIN>){
		chomp;
		if(/^(\d+) \+ (\d+) in total/){
			$hash{$name}{all_read} = $1;
		}elsif(/^(\d+) \+ (\d+) properly paired /){
			$hash{$name}{map_prop} = $1;
		}elsif(/^(\d+) \+ (\d+) mapped/){
			$hash{$name}{map_all}  = $1;
		}
	}
	close FIN;
}

open FOUT,">$output";
print FOUT "sample\tall_read\tmapped_read\tmapped_ratio\n";
foreach my $name(sort keys %hash){
	my $mapped_ratio = sprintf "%.2f",$hash{$name}{map_prop}/$hash{$name}{all_read}*100;
	print FOUT $name,"\t",$hash{$name}{all_read},"\t";
	print FOUT $hash{$name}{map_prop},"\t";
	print FOUT $mapped_ratio."%","\n";
}
close FOUT;
