#!/usr/bin/env perl
use strict;
use warnings;
use Carp;
use Getopt::Long;
use Cwd;
use FindBin;
use File::Basename;
use Data::Dumper;
use Parallel::ForkManager;

my $help;
my $head;
my $outfile;
my $g2t;

&GetOptions(
    'help!'     => \$help,
	'head=i'    => \$head,
	'outfile=s' => \$outfile,
);

if ($help) {
    &usage;
}

$head ||= 0;

if (scalar(@ARGV) < 1) {
	print STDERR "Error: files must be specified ! \n";
	&usage;
}

open  FOUT,">$outfile" or die "can not open $outfile ! \n";
my $i = 0;
foreach my $file(@ARGV){
	$i++;
	open FIN,$file or die "can not open $file ! \n";
	my $h = <FIN>;
	if($i == 1){
		print FOUT $h;
	}
	while(<FIN>){
		print FOUT $_;
	}
	close FIN;
}
close FOUT;

sub usage{
	my $s = basename($0);
	die(qq/
usage: perl $s -head 1 -outfile result.txtx file-1 file-2 file-3
#################################################################################################
#  Required:
#
#  --head    <string>         the directory path of ballgown input generate by stringtie or Tablemaker [required]
#
#  --outfile <string>         output dir, default is 'output'
#
#  --help    <NA>             help information
###############################################################################################
\n/);
}
