refer_gtf=$1
outdir=$2

gtfToGenePred -genePredExt $refer_gtf $outdir/genome.genePred_1
cut -f 13   $outdir/genome.genePred_1 > $outdir/genome.genePred_a
cut -f 1-10 $outdir/genome.genePred_1 > $outdir/genome.genePred_b
paste $outdir/genome.genePred_a $outdir/genome.genePred_b > $outdir/genome.genePred
rm $outdir/genome.genePred_1 $outdir/genome.genePred_a $outdir/genome.genePred_b