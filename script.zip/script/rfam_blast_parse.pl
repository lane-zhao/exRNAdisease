#!/usr/bin/env perl
use strict;
use warnings;
use Carp;
use Bio::SearchIO;
use Getopt::Long;
use Bio::DB::Fasta;
use List::Util qw ( sum);
use Math::Round qw(:all);
use File::Basename;

my %opts;
my $VERSION="1.0";
GetOptions( \%opts,
	"blast=s",
	"fasta=s", 
	"seed=s",
	"outdir=s",
	"prefix=s",
	"o=s",
	"maxEvalue=f",
	"minIdentity=i",
	"sumary=s",
	"unmatch=s", 
	"help!");

my $usage = <<"USAGE";
	Program : $0
	Version : $VERSION
	Lastest modify: 2019-12-07
	Discription: statistics for rfam blast result
	Usage :perl $0 [options]
		-blast*        blast to rfam database output
		-fasta*        fasta file of sequence  
		-seed          rfam seed file
		-outdir        outdir of result, default is './'
		-prefix        prefix name of output files, default is 
		-maxEvalue     Max E value, default is 1e-5	
		-minIdentity   Min percent(or positive) identity over the alignment, default is 50 
		-help          Display this usage information
		*              must be given Argument
USAGE

die $usage if ( !( $opts{blast} && $opts{fasta} ) || $opts{help} ); 

$opts{seed}   = $opts{seed}   ? $opts{seed}   : "/mnt/nfs/users/pub/database/blastdb/blast/Rfam.seed";
$opts{outdir} = $opts{outdir} ? $opts{outdir} : "./";
$opts{prefix} = $opts{prefix} ? $opts{prefix} : basename($opts{blast});
$opts{maxEvalue}   = $opts{maxEvalue}   ? $opts{maxEvalue}   : 1e-5;
$opts{minIdentity} = $opts{minIdentity} ? $opts{minIdentity} : 50;
system("mkdir -p $opts{outdir}");

my %seed;
my $id;
open SEED, "< $opts{seed}" or die "Error:Cannot open file  $opts{seed} : $! \n";
while(<SEED>){
	chomp;
	if(/^#=GF\s+AC\s+(\S+)\s*$/){
		$id=$1;
	}elsif(/^#=GF\s+DE\s+(.*)\s*$/){
		$seed{$id}{DE}=$1;
		#print "$1\n";
	}elsif(/^#=GF\s+TP\s+(.*)\s*$/){
		$seed{$id}{TP}=$1;
	}
}
close SEED;

my $fastadb = Bio::DB::Fasta->new("$opts{fasta}",(-reindex=>1));
my @ids     = $fastadb->get_all_ids;

my %sumary;
my %matched_names;
my $searchio= Bio::SearchIO->new(
	-format => 'blast',
	-file   => $opts{blast},
);

open  TABLE,">$opts{outdir}/$opts{prefix}.rfam_table.xls" or die "Error:Cannot open file $opts{outdir}/$opts{prefix}.rfam_table.xls: $! \n";
print TABLE "query_name\tDE\tTP\tAC\tHit\tstrand\tEvalue\tIdentity\n";
while(my $result = $searchio->next_result){
	while(my $hit = $result->next_hit){
		my $hsp= $hit->hsp; #Bio::Search::HSP::HSPI
		if($opts{'maxEvalue'}){
			next if $hsp->evalue > $opts{'maxEvalue'};
		}
		if($opts{'minIdentity'}){
			next if $hsp->frac_conserved('total') < $opts{'minIdentity'}/100;
		}
		$matched_names{$result->query_name}=1;
		$hit->name =~ /^([\w\-]+);.*/;
		my $c = $1;
		print TABLE $result->query_name."\t".$seed{$c}{DE}."\t".$seed{$c}{TP}."\t".$c."\t".$hit->name."\t".$hsp->strand('hit')."\t".$hsp->evalue."\t".$hsp->frac_conserved('total')."\n";
		
		$sumary{$seed{$c}{TP}}++;
		#print $1."\n";
		#print $hsp->frac_conserved('total') ."\n";
		#print $result->query_name."\t".$hit->name."\t".$hsp->evalue."\t".$hsp->strand('hit')."\t".$hsp->length('hit')."\t".$hsp->hit->start."\t".$hsp->hit->end."\t".$hsp->length('query')."\t".$hsp->query->start."\t".$hsp->query->end."\n";
		last;
	}
}
close TABLE;

open SUMARY, ">$opts{outdir}/$opts{prefix}.rfam_summary.xls" or die "Error:Cannot open file $opts{outdir}/$opts{prefix}.rfam_summary.xls: $! \n";
print SUMARY "TP\ttotal_num\ttotal_percent\n";
my $total_all=scalar(@ids);
print SUMARY "Total_all\t".$total_all."\t100%\n";

my $match_total_all=sum(values(%sumary));

print SUMARY "all_matched\t$match_total_all\t".nearest(.01, $match_total_all/$total_all * 100)."%\n";

my (@key,@values);
my $other=0;
my $r_out;
my $unmatch=$total_all-$match_total_all;
foreach my $t (keys(%sumary)){
	my $total_percent=nearest(.01, $sumary{$t}/$total_all * 100);
	print SUMARY "$t\t".$sumary{$t}."\t".$total_percent."%\n";
	
	if($sumary{$t}/$total_all>=0.005){
		push(@key,'"'.$t.'"');
		push(@values,$sumary{$t});
	}else{
		$other+=$sumary{$t};
	}	
}
close SUMARY;

if(scalar(@key)>=1){
	$r_out ="pdf(file=\"$opts{outdir}/$opts{prefix}.rfam_stat.pdf\",height=9,width=9)\n";
	$r_out.="slices<-c(".join(",",@values).",$other,$unmatch)\n";
	$r_out.="lbls<-c(".join(",",@key).",\"Other\",\"Unmatched\")\n";
	$r_out.="pct<-round(slices/sum(slices)*100,2)\n";
	$r_out.="lbls<-paste(lbls,pct)\n";
	$r_out.="lbls<-paste(lbls,\"%\",sep=\"\")\n";
	$r_out.="pie(slices,labels=lbls,col=rainbow(length(lbls)),main=\"$opts{prefix} rfam statistics\")\n";
	$r_out.="dev.off()\n";
	open R, "> $opts{outdir}/$opts{prefix}.rfam_stat.R" or die "Error:Cannot open file $opts{outdir}/$opts{prefix}.rfam_stat.R : $! \n";     
	print R $r_out;
	close R;     
	system("R --no-save < $opts{outdir}/$opts{prefix}.rfam_stat.R");
	system("convert $opts{outdir}/$opts{prefix}.rfam_stat.pdf -append -flatten $opts{outdir}/$opts{prefix}.rfam_stat.png");
}

open UNMATCH, ">$opts{outdir}/$opts{prefix}.rfam_unmatch.txt" or die "Error:Cannot open file $opts{outdir}/$opts{prefix}.rfam_unmatch.txt: $! \n";
foreach my $s (@ids){
	unless(exists($matched_names{$s})){
		print UNMATCH "$s\n";
	}
}
close UNMATCH;
