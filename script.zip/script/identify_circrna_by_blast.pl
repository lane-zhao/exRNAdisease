#!/usr/bin/env perl
use strict;
use warnings;
use Getopt::Long;
use Data::Dumper;
use Config::IniFiles;
use Cwd qw/abs_path/;
use FindBin qw($Bin $Script $RealBin);
use File::Basename qw(basename dirname);
use BioQueue::Queue;
use POSIX;

require "/mnt/nfs/users/pub/software/modules/4.3.1/init/perl.pm";

&module('load', 'diamond/v0.9.19.120', 'TransDecoder/r20131110','hmmer/3.1b2');

my $BEGIN_TIME=time();
my $script   = "$Bin/script";
my $database = "/mnt/nfs/users/pub/database";

my ($seq_file,$seq_numb,$chunksize,$blast_method,$blast_cpu,$blast_evalue,$help,%db,$flag_unigene,$gene);
my ($max_jobs, $max_cpus, $max_mems, $partition, $job_prefix, $job_mode, $queue_rerun, $queue_level);

GetOptions(
	"fasta:s"        => \$seq_file,
	"number:s"       => \$seq_numb,
	"unigene!"       => \$flag_unigene,
	"chunksize:i"    => \$chunksize,
	
	"blast_method:i" => \$blast_method,
	"blast_cpu:i"    => \$blast_cpu,
	"blast_evalue:s" => \$blast_evalue,
	
	"nr:s"           => \$db{nr},
	"swissprot:s"    => \$db{swissprot},
	"string:s"       => \$db{string},
	"kegg:s"         => \$db{kegg},
	
	"max_cpus:i"   => \$max_cpus,
	"max_mems:i"   => \$max_mems,
	"max_jobs:i"   => \$max_jobs,
	"partition:s"  => \$partition,
	"job_prefix:s" => \$job_prefix,
	"job_mode:s"   => \$job_mode,
	"queue_rerun!" => \$queue_rerun,
	"help!"        => \$help,
);

&parsing_parameters();

my %depend_parsing;
my %depend_merge;
my %CLASS;
my @fa_files;
my %IDs;
my $outdir    = abs_path("annotation");
my $tmpdir    = abs_path("tmp");
my $tmp_fasta = "$tmpdir/fasta";
my $tmp_blast = "$tmpdir/blast";
my $tmp_merge = "$tmpdir/merge";
system("mkdir -p $outdir");
system("mkdir -p $tmpdir $tmp_fasta $tmp_blast $tmp_merge");

my $queue = BioQueue::Queue->new(
	{
		'partition'   => $partition,
		'job_pref'    => $job_prefix,
		'job_mode'    => $job_mode,
		'max_cpus'    => $max_cpus,
		'max_mems'    => $max_mems,
		'max_jobs'    => $max_jobs,
		'queue_rerun' => $queue_rerun,
		'queue_level' => $queue_level,
	}
);

&run_split();
&run_blast();

&run_g2t();

&run_orf();
&run_pfam();
&run_nr();
&run_cog_kog();
&run_go();
&run_kegg();

&bigtable();
&annotstat();
$queue->jointhreads();

print " all jobs done!\n";

###########################################################################

sub parsing_parameters{
	if($help){
		&usage;
	}
	unless(defined($seq_file)){
		print STDERR "please specifiy fasta file!";
		&usage;
	}
	unless(-e $seq_file){
		print STDERR "fasta file[$seq_file] does not exist!";
		&usage;
	}
	$seq_file       = abs_path($seq_file);
	$seq_type     ||= "nuc";
	$chunksize    ||= 10000;
	$blast_cpu    ||= 10;
	$blast_method ||= 'diamond';
	$blast_evalue ||= '1E-5';
	$partition    ||= 'small';
	$job_prefix   ||= 'ann';
	$max_cpus     ||= 200;
	$max_mems     ||= 300;
	$max_jobs     ||= 20;
	$queue_rerun  ||= 0;
	$job_mode     ||= "pbs";
	$queue_level  ||= "run_strict";

	if($seq_type ne "nuc" && $seq_type ne "pro"){
		print STDERR "ftype must be nuc or pro!";
		&usage;
	}
	if($g2t){
		$g2t = abs_path($g2t);
		unless(-e $g2t){
			print STDERR "g2t file[$g2t] dose not exists!";
			&usage;
		}
	}
	if($chunksize <= 0){
		die "Error: chunksize must larger than 0 !!\n";
	}
	if($blast_method ne "diamond"){
		print STDERR "blast_method must be diamond now!";
		&usage;
	}
	if($flag_unigene){
		$gene = "unigene";
	}else{
		$gene = "gene";
	}
	# if($blast_method ne "diamond" && $seq_type ne "blast" && $seq_type ne "mblast"){
		# print STDERR "blast_method must be diamond, blast or mblast!";
		# &usage;
	# }
	# my $ret_test_file = `$script/sanity_check_genome.pl $seq_file 2>&1`;
	# if ( $seq_type =~ /^nuc/ ) {
		# if ($ret_test_file) {
			# die("error: fasta file $seq_file type:$seq_type formart error!\n$ret_test_file");
		# }
	# }else {
		# if ( !$ret_test_file || length($ret_test_file) < 1 ) {
			# die("error: fasta file $seq_file type:$seq_type formart error! It seems to not like a protien file\n");
		# }
	# }
	foreach my $dbname(qw/nr swissprot string kegg/){
		my $skip = 0;
		if(!$db{$dbname}){
			$db{$dbname} = "$database/blastdb/$blast_method/".$dbname;
		}elsif($db{$dbname} eq "no"){
			warn("$dbname annotation will be skipped!");
			$skip = 1;
		}elsif($db{$dbname} !~ /^\//){
			$db{$dbname} = "$database/blastdb/$blast_method/".$db{$dbname};
		}
		unless($skip){
			unless(-e $db{$dbname} || -e $db{$dbname}.".dmnd"){
				die("error: $dbname database[$db{$dbname}] does not exist!");
			}
		}
	}
}

sub run_split{
	my $seq_num  = fastalength($seq_file);
	
	my $file_num = POSIX::ceil($seq_num/$chunksize);
	for(my $i = 1; $i <= $file_num; $i++){
		my $x = convert_id($i);
		$IDs{convert_id($i)}++;
		push @fa_files, "$tmp_fasta/transcript.fa_$x.split";
	}
	
	my $fa_file = "$tmp_fasta/transcript.fa";
	
	$queue->set_job_cpu(1);
	$queue->set_job_mem(1);
	$queue->set_job_mode($job_mode);
	$queue->set_job_name("split.fasta");
	$queue->set_job_disc("拆分输入序列");
	$queue->set_file_check(join(",",@fa_files));
	$queue->set_work_dir($tmp_fasta);
	$queue->addcommonds('sed \'s/^>\(\S*\).*/>\1/g\' '. $seq_file . " > $fa_file");
	$queue->addcommonds("$script/splitfasta.pl $fa_file $chunksize" );
	$queue->run();
}

sub fastalength {
	my $fasta = shift;
	my $num   = `grep '^>' -c $fasta`;
	chomp($num);

	return $num;
}

sub run_blast {
	my %xml_files;
	my %tab_files;
	
	my %dependencies;
		
	foreach my $fa_file (@fa_files) {
		my $fa_name    = basename($fa_file);
		my $db_method  = "db_$blast_method";
		my $blast_type = "blastp";
		if ( $seq_type eq "nuc" ) {
			$blast_type = "blastx";
		}
		
		if ( $seq_type eq "nuc") {
			$dependencies{"pfam"}{"blast2pfam.$fa_name"}++;
			$queue->set_job_cpu($blast_cpu);
			$queue->set_job_mem(10);
			$queue->set_job_mode($job_mode);
			$queue->set_job_name("blast2pfam.$fa_name");
			$queue->set_job_disc("[".$fa_name. "]比对[pfam]库");
			$queue->set_job_depend("split.fasta");
			$queue->set_file_check("");
			$queue->set_work_dir($tmp_blast);
			$queue->addcommonds("module load TransDecoder/r20131110");
			$queue->addcommonds("TransDecoder -t $fa_file -S -T 3000 -m 100 --search_pfam $database/Pfam/28.0/Pfam-A.hmm --CPU $blast_cpu");
			$queue->run();
		}else{
			
		}
		
		foreach my $db_name(qw/nr swissprot string kegg/){
			if ( $db{$db_name} ne "no" ) {
				my $out_xml = "$tmp_blast/$fa_name\_vs_$db_name.xml";
				my $out_tab = "$tmp_blast/$fa_name\_vs_$db_name.tab";
				
				push @{$tab_files{$db_name}},$out_tab;
				
				$dependencies{$db_name}{"blast2$db_name.$fa_name"}++;
				$queue->set_job_cpu($blast_cpu);
				$queue->set_job_mem(15);
				$queue->set_job_mode($job_mode);
				$queue->set_job_name("blast2$db_name.$fa_name");
				$queue->set_job_disc("[$fa_name]比对[$db_name]库");
				$queue->set_job_depend("split.fasta");
				$queue->set_file_check("");
				if($blast_method eq "diamond"){
					#$queue->addcommonds("diamond $blast_type --strand plus --db $db{$db_name} --query $fa_file --evalue $blast_evalue --outfmt 5 --threads $blast_cpu --max-target-seqs 5 --out $out_xml");
					$queue->addcommonds("diamond $blast_type --strand plus --db $db{$db_name} --query $fa_file --evalue $blast_evalue --outfmt 6 qseqid sseqid pident ppos length mismatch gapopen qlen qstart qend slen sstart send evalue bitscore stitle --threads $blast_cpu --max-target-seqs 5  --out $out_tab");
				}else{
					#$queue->addcommonds("$blast_type -query $fa_file -db $db{$db_name} -out $out_xml -evalue $blast_evalue -outfmt 5 -num_threads $blast_cpu -max_target_seqs 5");
					$queue->addcommonds("$blast_type -query $fa_file -db $db{$db_name} -out $out_tab -evalue $blast_evalue -outfmt 6 -num_threads $blast_cpu -max_target_seqs 5");
				}
				#$queue->addcommonds("$script/Blast2table -format 10 -xml $out_xml > $out_tab");
				$queue->run();
			}
		}
	}
	
	foreach my $db_name(qw/nr swissprot string kegg pfam/){
		if ( $db_name eq "pfam" ){
			if ( $seq_type eq "nuc") {
				$depend_merge{"mergeblast.pfam"}++;
				$queue->set_job_cpu(1);
				$queue->set_job_mem(1);
				$queue->set_job_mode($job_mode);
				$queue->set_job_name("mergeblast.pfam");
				$queue->set_job_disc("合并["."pfam"."]库");
				$queue->set_job_depend(join(",",sort keys %{$dependencies{"pfam"}}));
				$queue->set_file_check("$tmp_merge/transcript_vs_pfam.blasttable.xls");
				$queue->set_work_dir($tmpdir);
				my $in  = "$tmp_blast/transcript.fa_*.split";
				#$queue->addcommonds("cat $in.transdecoder.bed | grep -v '^track name' > $tmp_merge/transcript.transdecoder.bed");
				#$queue->addcommonds("cat $in.transdecoder.gff3            > $tmp_merge/transcript.transdecoder.gff3");
				#$queue->addcommonds("cat $in.transdecoder.pfam.dat        > $tmp_merge/transcript.transdecoder.pfam.domtbl.xls");
				#$queue->addcommonds("cat $in.transdecoder.pfam.dat.tbl    > $tmp_merge/transcript.pfam.temp.xls");
				$queue->addcommonds("cat $tmp_blast/transcript.fa_*.split.transdecoder.cds             > $tmp_merge/transcript.cds.fasta");
				$queue->addcommonds("cat $tmp_blast/transcript.fa_*.split.transdecoder.pep             > $tmp_merge/transcript.pep.fasta");
				$queue->addcommonds("cat $tmp_blast/transcript.fa_*.split.transdecoder.pfam.dat.domtbl > $tmp_merge/transcript.transdecoder.pfam.dat.domtbl");
				$queue->addcommonds("$script/generate_pfamtab_from_pfamdomtbl.pl $tmp_merge/transcript.transdecoder.pfam.dat.domtbl $tmp_merge/transcript_vs_pfam.blasttable.xls");
				$queue->run();
			}
		}elsif ( $db{$db_name} ne "no" ) {
			$depend_merge{"mergeblast.$db_name"}++;
			$queue->set_job_cpu(1);
			$queue->set_job_mem(1);
			$queue->set_job_mode($job_mode);
			$queue->set_job_name("mergeblast.$db_name");
			$queue->set_job_disc("合并[$db_name]库");
			$queue->set_job_depend(join(",",sort keys %{$dependencies{$db_name}}));
			$queue->set_file_check("$tmp_merge/transcript_vs_$db_name.blasttable.xls");
			$queue->set_work_dir($tmpdir);
			$queue->addcommonds('echo -e "#Query_id\tSubject_id\tIdentity%\tSimilarity%\tAlign_length\tMismatches\tGap_open\tQ_len\tQ_start\tQ_end\tS_len\tS_start\tS_end\tEvalue\tHBit_score\tStitle"> ' . "$tmp_merge/transcript_vs_$db_name.blasttable.xls.tmp");
			#$queue->addcommonds('echo -e #"Score\tE-Value\tHSP-Len\t%-Ident\t%-Simil\tQuery-Name\tNum-Rds\tQ-Len\tQ-Begin\tQ-End\tQ-Frame\tHit-Name\tH-Len\tH-Begin\tH-End\tH-Frame\tDescription"> ' . "$tmp_merge/transcript_vs_$db_name.blasttable.xls.tmp");
			$queue->addcommonds("cat $tmp_blast/transcript.fa_*.split_vs_$db_name.tab >> $tmp_merge/transcript_vs_$db_name.blasttable.xls.tmp");
			$queue->addcommonds("$script/blast_filter.pl -blast $tmp_merge/transcript_vs_$db_name.blasttable.xls.tmp -best -output $tmp_merge/transcript_vs_$db_name.blasttable.xls");
			$queue->run();
		}
	}
}

sub run_g2t{
	$CLASS{"transcript"}++;
	if(defined($g2t)){
		$CLASS{$gene}++;
		
		$queue->set_job_cpu(1);
		$queue->set_job_mem(1);
		$queue->set_job_mode($job_mode);
		$queue->set_job_name("parsing.g2t");
		$queue->set_job_disc("处理基因和转录ID的对应关系,并转化表格");
		$queue->set_job_depend(join(",",sort keys %depend_merge));
		$queue->set_file_check("");
		
		$queue->addcommonds("cp $tmp_fasta/transcript.fa $tmp_merge/transcript.fa");
		$queue->addcommonds("$script/transcript_2_unigene_seq.pl -fasta $tmp_fasta/transcript.fa -g2t $g2t -out1 $tmp_fasta/$gene.fa -out2 $tmp_fasta/$gene\_2_transcript.xls");
		
		my @tmp;
		foreach my $db_name(qw/nr swissprot string kegg pfam/){
			if ( $db_name eq "pfam" ){
				push @tmp,$db_name;
				$queue->addcommonds("$script/transcript_2_unigene_orf.pl -fasta $tmp_merge/transcript.cds.fasta -out $tmp_merge/$gene.cds.fasta -g2t $tmp_fasta/$gene\_2_transcript.xls");
				$queue->addcommonds("$script/transcript_2_unigene_orf.pl -fasta $tmp_merge/transcript.pep.fasta -out $tmp_merge/$gene.pep.fasta -g2t $tmp_fasta/$gene\_2_transcript.xls");
				$queue->addcommonds("$script/transcript_2_unigene_tab.pl -transcript $tmp_merge/transcript_vs_pfam.blasttable.xls -unigene $tmp_merge/$gene\_vs_pfam.blasttable.xls -g2t $tmp_fasta/$gene\_2_transcript.xls -col 1 -skip 1");
			}elsif ( $db{$db_name} ne "no" ) {
				push @tmp,$db_name;
				$queue->addcommonds("$script/transcript_2_unigene_tab.pl -transcript $tmp_merge/transcript_vs_$db_name.blasttable.xls -unigene $tmp_merge/$gene\_vs_$db_name.blasttable.xls -g2t $tmp_fasta/$gene\_2_transcript.xls -col 1 -skip 1");
			}
		}
		$queue->run();
	}
}

sub run_orf{
	return if $seq_type ne "nuc";
	$depend_parsing{"parsing.orf"}++;
	$queue->set_job_cpu(1);
	$queue->set_job_mem(1);
	$queue->set_job_mode($job_mode);
	$queue->set_job_name("parsing.orf");
	$queue->set_job_disc("整理ORF预测结果");
	if(defined($g2t)){
		$queue->set_job_depend("parsing.g2t");
	}else{
		$queue->set_job_depend("mergeblast.pfam");
	}
	$queue->set_file_check("");
	$queue->set_work_dir("$outdir");
	$queue->addcommonds("mkdir -p $outdir/ORF");
	$queue->addcommonds("cd $outdir/ORF");
	foreach my $class(sort keys %CLASS){
		$queue->addcommonds("cp $tmp_merge/$class.cds.fasta  $outdir/ORF");
		$queue->addcommonds("cp $tmp_merge/$class.pep.fasta  $outdir/ORF");
	}
	$queue->run();
}

sub run_pfam{
	$depend_parsing{"parsing.pfam"}++;
	$queue->set_job_cpu(1);
	$queue->set_job_mem(1);
	$queue->set_job_mode($job_mode);
	$queue->set_job_name("parsing.pfam");
	$queue->set_job_disc("整理PFAM结果");
	if(defined($g2t)){
		$queue->set_job_depend("parsing.g2t");
	}else{
		$queue->set_job_depend("mergeblast.pfam");
	}
	$queue->set_file_check("$outdir/PFAM/transcript.pfam.xls");
	$queue->set_work_dir("$outdir");
	$queue->addcommonds("mkdir -p $outdir/PFAM");
	$queue->addcommonds("cd $outdir/PFAM");
	foreach my $class(sort keys %CLASS){
		$queue->addcommonds("cp $tmp_merge/$class\_vs_pfam.blasttable.xls  $outdir/PFAM/$class.pfam.xls");
	}
	$queue->run();
}

sub run_nr{
	if ( $db{'nr'} ne "no" ){
		$depend_parsing{"parsing.nr"}++;
		$queue->set_job_cpu(2);
		$queue->set_job_mem(5);
		$queue->set_job_mode($job_mode);
		$queue->set_job_name("parsing.nr");
		$queue->set_job_disc("整理NR结果");
		if(defined($g2t)){
			$queue->set_job_depend("parsing.g2t");
		}else{
			$queue->set_job_depend("mergeblast.nr");
		}
		$queue->set_file_check("");
		$queue->set_work_dir("$outdir");
		$queue->addcommonds("mkdir -p $outdir/NR");
		$queue->addcommonds("cd $outdir/NR");
		foreach my $class(sort keys %CLASS){
			$queue->addcommonds("$script/plot_similarity.pl $tmp_merge/$class\_vs_nr.blasttable.xls $class");
			$queue->addcommonds("$script/plot_evalue.pl     $tmp_merge/$class\_vs_nr.blasttable.xls $class");
			$queue->addcommonds("$script/plot_taxonomy.pl   $tmp_merge/$class\_vs_nr.blasttable.xls $class");
		}
		$queue->run();
	}
}

sub run_cog_kog{
	if ( $db{'string'} ne "no" ){
		$depend_parsing{"parsing.cog_kog"}++;
		$queue->set_job_cpu(2);
		$queue->set_job_mem(5);
		$queue->set_job_mode($job_mode);
		$queue->set_job_name("parsing.cog_kog");
		$queue->set_job_disc("整理COG_KOG结果");
		if(defined($g2t)){
			$queue->set_job_depend("parsing.g2t");
		}else{
			$queue->set_job_depend("mergeblast.string");
		}
		$queue->set_file_check("");
		
		$queue->set_work_dir("$outdir");
		$queue->addcommonds("mkdir -p $outdir/COG_KOG");
		$queue->addcommonds("cd $outdir/COG_KOG");
		foreach my $class(sort keys %CLASS){
			$queue->addcommonds("$script/string2cog.pl -i $tmp_merge/$class\_vs_string.blasttable.xls -o $outdir/COG_KOG/ -img COG,KOG -pre $class");
		}
		$queue->run();
	}
}

sub run_go{
	if ( $db{'swissprot'} ne "no" ){
		$depend_parsing{"parsing.go"}++;
		$queue->set_job_cpu(2);
		$queue->set_job_mem(5);
		$queue->set_job_mode($job_mode);
		$queue->set_job_name("parsing.go");
		$queue->set_job_disc("整理GO结果");
		if(defined($g2t)){
			$queue->set_job_depend("parsing.g2t");
		}else{
			$queue->set_job_depend("mergeblast.swissprot");
		}
		$queue->set_file_check("");
		$queue->set_work_dir("$outdir");

		$queue->addcommonds("mkdir -p $outdir/GO");
		$queue->addcommonds("cd $outdir/GO");
		
		foreach my $class(sort keys %CLASS){
			$queue->addcommonds("$script/go_annot_from_blast_swissprot.pl -i $tmp_merge/$class\_vs_swissprot.blasttable.xls -o $class\.GO.txt");
			$queue->addcommonds("$script/go_level_one.pl -i $class\.GO.txt -level 2 -list $class\.GO.level2.info.xls -stat $class\.GO.level2.stat.xls -plot $class\.GO.level2.pdf");
			#$queue->addcommonds("$script/go_plot_bar.pl -i $class\.GO.level2.stat.xls");
			$queue->addcommonds("$script/go_level_three.pl -i $class\.GO.txt -o $class -pie T");
		}
		$queue->run();
	}
}

sub run_kegg{
	if ( $db{'kegg'} ne "no" ){
		$depend_parsing{"parsing.kegg"}++;
		$queue->set_job_cpu(2);
		$queue->set_job_mem(5);
		$queue->set_job_mode($job_mode);
		$queue->set_job_name("parsing.kegg");
		$queue->set_job_disc("整理KEGG结果");
		if(defined($g2t)){
			$queue->set_job_depend("parsing.g2t");
		}else{
			$queue->set_job_depend("mergeblast.kegg");
		}
		$queue->set_file_check("");
		$queue->set_work_dir("$outdir");
		
		$queue->addcommonds("mkdir -p $outdir/KEGG");
		$queue->addcommonds("cd $outdir/KEGG");
		foreach my $class(sort keys %CLASS){
			$queue->addcommonds("$script/kegg_annot_from_blast.pl -input $tmp_merge/$class\_vs_kegg.blasttable.xls -format blast -out $class.pathway_image --prefix $class");
			$queue->addcommonds("$script/kegg_level_2.pl -input $class.pathway_info.xls -out $class.pathway_classification -name $class");
			$queue->addcommonds("$script/kegg_plot_top20bars.pl -t $class.pathway_info.xls");
			$queue->addcommonds("cp $class.pathway_info.xls.top20.pdf $class.pathway_top20.pdf");
			$queue->addcommonds("rm $class.pathway_info.xls.top20.pdf");
			$queue->addcommonds("");
		}
		$queue->run();
	}
}

sub bigtable{
	$queue->set_job_cpu(2);
	$queue->set_job_mem(5);
	$queue->set_job_mode($job_mode);
	$queue->set_job_name("bigtable");
	$queue->set_job_disc("生成综合注释表格");
	$queue->set_job_depend(join(",",sort keys %depend_parsing));
	$queue->set_file_check("");
	$queue->set_work_dir("$outdir");
	
	foreach my $class(sort keys %CLASS){
		my $cmd      = "$script/mergeAnnotation.pl -fa $tmp_fasta/$class.fa";
		if ( $db{'nr'} ne "no" ) {
			$cmd .= " -nr $tmp_merge/$class\_vs_nr.blasttable.xls";
		}
		if ( $db{'string'} ne "no" ) {
			$cmd .= " -string $outdir/COG_KOG/$class.cog_table.xls -cog $outdir/COG_KOG/$class.cog_list.xls";
		}
		if ( $db{'swissprot'} ne "no" ) {
			$cmd .= " -swissprot $tmp_merge/$class\_vs_swissprot.blasttable.xls";
		}
		if ( $db{'kegg'} ne "no" ) {
			$cmd .= " -kegg $outdir/KEGG/$class.query_info.xls";
		}
		if ( $db{'nr'} ne "no" ) {
			#$cmd .= " -go $outdir/GO/$class.GO.txt";
			$cmd .= " -go $outdir/GO/$class.GO.level1.xls";
		}
		if(1){
			$cmd .= " -cds $outdir/ORF/$class.cds.fasta";
		}
		if(1){
			$cmd .= " -pfam $outdir/PFAM/$class.pfam.xls";
		}
		$cmd .= "  > $outdir/$class.annotation.table.xls";
		$queue->addcommonds($cmd);
		
		$queue->addcommonds("sed '1s/^#Qeury_name\\tQeury_length/$class\_id\\t$class\_length/' $outdir/$class.annotation.table.xls > $outdir/$class.annotation.xls");
		# $queue->addcommonds("cp $outdir/$class.annotation.table.xls $outdir/$class.annotation.xls");
		# $queue->addcommonds("sed -i 's/^#Qeury_name/$class\_id/' $outdir/$class.annotation.xls");
		# $queue->addcommonds("sed -i 's/Qeury_length/$class\_length/' $outdir/$class.annotation.xls");
	}
	$queue->run();
	
}

sub annotstat{
	$queue->set_job_cpu(2);
	$queue->set_job_mem(5);
	$queue->set_job_mode($job_mode);
	$queue->set_job_name("annotstat");
	$queue->set_job_disc("注释统计");
	$queue->set_job_depend("bigtable");
	$queue->set_file_check("");
	$queue->set_work_dir("$outdir");
	
	foreach my $class(sort keys %CLASS){
		$queue->addcommonds("$script/annotstat.pl -anno $outdir/$class.annotation.table.xls -out $outdir/$class.temp");
	}
	if(scalar keys %CLASS eq 2){
		$queue->addcommonds("join -t \$\'\\t\' $outdir/$gene.temp $outdir/transcript.temp > $outdir/annotstat.temp");
		$queue->addcommonds("echo -e 'type\\t$gene\\ttranscript' > $outdir/annotstat.head");
	}else{
		$queue->addcommonds("cat $outdir/transcript.temp > $outdir/annotstat.temp");
		$queue->addcommonds("echo -e 'type\\ttranscript' > $outdir/annotstat.head");
	}
	$queue->addcommonds("cat $outdir/annotstat.head $outdir/annotstat.temp > $outdir/annotstat.xls");
	$queue->addcommonds("rm $outdir/annotstat.head $outdir/*.temp");
	
	$queue->run();
}

sub convert_id{
	my ($x) = @_;
	if($x<10){
		return "00$x";
	}elsif($x<100){
		return "0$x";
	}elsif($x<1000){
		return "$x";
	}else{
		die "the number of splited files is too much!!! please modity chunk size!!";
	}
}


sub usage{
	my $program = basename($0);
    die "
Version: v3.0
Create : 20191109
Aurthor: guantao.zheng\@origin-gene.com
Usage  : $program <arguments>
Arguments:
  Input Options:
    --fasta         <string>    input fasta file [required]
    --ftype         <string>    sequence type, only support nuc and pro. default is nuc [ optional ]
    --g2t           <string>    unigene 2 transcript map file [ required ]
    --unigene       <null>      weather use unigene instead of gene
    --chunksize     <number>    chunk size, default is 10000  [ optional ]

  Advanced Options:
    --blast_method  <string>    blast method. now only support diamond! default is diamond  [ optional ]
    --blast_cpu     <number>    blast cpu number. default is 10  [ optional ]
    --blast_evalue  <string>    blast evalue threshold. default is 1E-5  [ optional ]

  Database Options:
    --nr            <string>    nr database name, default is 'nr'. skip this annotation when set 'no'
    --kegg          <string>    kegg database name, default is 'kegg'. skip this annotation when set 'no'
    --string        <string>    string database name, default is 'string'. skip this annotation when set 'no'
    --swissprot     <string>    swissprot database name, default is 'swissprot'. skip this annotation when set 'no'

  General Options:
    --max_cpus      <number>    queue's max cpu number limitation, default is 300 [ optional ]
    --max_mems      <number>    queue's max mem size limitation[G], default is 500 [optional]
    --max_jobs      <number>    queue's max job number limitation, default is 30  [ optional ]
    --partition     <string>    slurm or pbs partition, default is 'small'
    --queue_level   <string>    queue level : 'only_cmd', 'run_strict', 'run_force'. default is 'run_strict'
    --queue_rerun   <null>      rerun all pipeline
    --job_prefix    <string>    jjob name prefix, default is 'm' [optional]
    --job_mode      <string>    job run mode : 'local', 'slurm' and 'pbs'. default is slurm
    --help          <null>      display help information [ optional ]
\n";
}





