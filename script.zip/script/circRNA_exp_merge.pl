#!/usr/bin/env perl
use strict;
use warnings;

@ARGV==2 || die "
	# Usage:   perl $0 [exp.list] [exp_merge.xls]
	# contact: guantao.zheng\@gmail.com
	# updata:  2018-03-06
";

my %exp;
my %samples;
open FIN,"<$ARGV[0]" or die "";
while(<FIN>){
	chomp;
	my ($sample,$file) = split /\t/,$_;
	$samples{$sample}++;
	open CIRI,"<$file" or die "";
	<CIRI>;
	while (<CIRI>){
		chomp;
		my ($id,$value) = split /\t/,$_;
		$exp{$id}{$sample} = $value;
	}
	close CIRI;
}

open FOUT,">$ARGV[1]";
print FOUT "circRNA_ID\t",join("\t",sort keys %samples),"\n";
foreach my $id(sort keys %exp){
	print FOUT $id;
	foreach my $sample(sort keys %samples){
		if(exists $exp{$id}{$sample}){
			print FOUT "\t",$exp{$id}{$sample};
		}else{
			print FOUT "\t",0;
		}
	}
	print FOUT "\n";
}
close FOUT;