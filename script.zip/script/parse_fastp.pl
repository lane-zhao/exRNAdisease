#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;
use Getopt::Long;
use Time::Local;
use JSON;
use Encode;
use Data::Dumper;

my %opts;
GetOptions (\%opts,
	"json=s", 
	"outdir=s", 
	"prefix=s",
	"help!",
);

my $program = basename($0);
my $usage = <<"USAGE";
  Program : $program
  Authour : guantao.zheng
  Discription: parsing fastp json result
  Usage: perl $program [options]
    --help      display help information
    --json*     fastp json file, required
    --outdir    output dir, default is ./
    --prefix    prefix name of output, default is 'sample'
  example: perl $0
USAGE

die $usage if ( !$opts{json} ||$opts{help} );

$opts{outdir} ||= "./";
$opts{prefix} ||= "sample";

system("mkdir -p $opts{outdir}");

print "读取json数据...\n";
my $json = new JSON;
my $js;
if(open(MYFILE, $opts{json} )){
	print "读取json数据成功!\n";
	while(<MYFILE>){
		$js .= "$_";
	}
}else{
	die "读取json数据失败!\n";
}

my $obj = $json->decode($js);
#print "json数据为:".Dumper($obj);

open  FOUT,">$opts{outdir}/$opts{prefix}.rawdata.stat.xls";
print FOUT "Sample_ID\tTotal_Reads\tTotal_Bases\tQ20_Bases\tQ30_Bases\tQ20_Rate(%)\tQ30_Rate(%)\tGC_Content(%)\n";
print FOUT $opts{prefix};
foreach my $x(qw/total_reads total_bases q20_bases q30_bases q20_rate q30_rate gc_content/){
	if(grep /^$x$/, qw/q20_rate q30_rate gc_content/){
		print FOUT "\t",$obj->{'summary'}->{'before_filtering'}->{$x} * 100;
	}else{
		my $v = $obj->{'summary'}->{'before_filtering'}->{$x};
		my $v_show = &digitize($v);
		print FOUT "\t",$v_show;
	}
}
print FOUT "\n";
close FOUT;

open  FOUT,">$opts{outdir}/$opts{prefix}.cleandata.stat.xls";
print FOUT "Sample_ID\tTotal_Reads\tTotal_Bases\tQ20_Bases\tQ30_Bases\tQ20_Rate(%)\tQ30_Rate(%)\tGC_Content(%)\n";
print FOUT $opts{prefix};
foreach my $x(qw/total_reads total_bases q20_bases q30_bases q20_rate q30_rate gc_content/){
	if(grep /^$x$/, qw/q20_rate q30_rate gc_content/){
		print FOUT "\t",$obj->{'summary'}->{'after_filtering'}->{$x} * 100;
	}else{
		my $v = $obj->{'summary'}->{'after_filtering'}->{$x};
		my $v_show = &digitize($v);
		print FOUT "\t",$v_show;
	}
}
print FOUT "\n";
close FOUT;

open  FOUT,">$opts{outdir}/$opts{prefix}.summary_filter.xls";
print FOUT "Sample_ID\tRaw_Total_Reads\tPassed_Filter_Reads\tLow_Quality_Reads\tToo_Many_N_Reads\tToo_Short_Reads\n";
print FOUT $opts{prefix};
foreach my $x(qw/total_reads/){
	my $v = $obj->{'summary'}->{'before_filtering'}->{$x};
	my $v_show = &digitize($v);
	my $percent= sprintf("%.2f",$v / $obj->{'summary'}->{'before_filtering'}->{'total_reads'} * 100);
	print FOUT "\t","$v_show($percent\%)";
}
foreach my $x(qw/passed_filter_reads low_quality_reads too_many_N_reads too_short_reads/){
	my $v = $obj->{'filtering_result'}->{$x};
	my $v_show = &digitize($v);
	my $percent= sprintf("%.2f",$v / $obj->{'summary'}->{'before_filtering'}->{'total_reads'} * 100);
	print FOUT "\t","$v_show($percent\%)";
}
print FOUT "\n";
close FOUT;

open  FOUT,">$opts{outdir}/$opts{prefix}.summary_qc.xls";
print FOUT "Sample_ID\tRaw_Total_Reads\tRaw_Total_Bases\tRaw_Q20_Rate(\%)\tRaw_Q30_Rate(\%)\tRaw_GC_Content(\%)\tClean_Total_Reads\tClean_Total_Bases\tClean_Q20_Rate(\%)\tClean_Q30_Rate(\%)\tClean_GC_Content(\%)\n";
print FOUT $opts{prefix};
foreach my $x(qw/total_reads total_bases q20_rate q30_rate gc_content/){
	if(grep /^$x$/, qw/q20_rate q30_rate gc_content/){
		print FOUT "\t",sprintf("%.2f",$obj->{'summary'}->{'before_filtering'}->{$x} * 100);
	}else{
		my $v = $obj->{'summary'}->{'before_filtering'}->{$x};
		my $v_show = &digitize($v);
		print FOUT "\t",$v_show;
	}
}
foreach my $x(qw/total_reads total_bases q20_rate q30_rate gc_content/){
	if(grep /^$x$/, qw/q20_rate q30_rate gc_content/){
		print FOUT "\t",sprintf("%.2f",$obj->{'summary'}->{'after_filtering'}->{$x} * 100);
	}else{
		my $v = $obj->{'summary'}->{'after_filtering'}->{$x};
		my $v_show = &digitize($v);
		print FOUT "\t",$v_show;
	}
}
print FOUT "\n";
close FOUT;

close(MYFILE);

sub digitize {
	my $v = shift or return '0';
	$v =~ s/(?<=^\d)(?=(\d\d\d)+$)     #处理不含小数点的情况
			|
			(?<=^\d\d)(?=(\d\d\d)+$)   #处理不含小数点的情况
			|
			(?<=\d)(?=(\d\d\d)+\.)     #处理整数部分
			|
			(?<=\.\d\d\d)(?!$)         #处理小数点后面第一次千分位，例子中就是.127后面的逗号
			|
			(?<=\G\d\d\d)(?!\.|$)      #处理小数点后第一个千分位以后的内容，或者不含小数点的情况
			/,/gx;
	return $v;
}
