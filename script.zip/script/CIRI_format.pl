#!/usr/bin/env perl
use strict;
use warnings;

my $head_1 = "circRNA_ID\tchr\tcircRNA_start\tcircRNA_end\t#junction_reads\tSM_MS_SMS\t#non_junction_reads\tjunction_reads_ratio\tcircRNA_type\tgene_id\tstrand\tjunction_reads_ID\n";
my $head_2 = "circRNA_ID\tchr\tcircRNA_start\tcircRNA_end\t#junction_reads\tSM_MS_SMS\t#non_junction_reads\tjunction_reads_ratio\tcircRNA_type\tgene_id\tgene_name\tstrand\n";

my $file_in = $ARGV[0];
my $file_out = $ARGV[1];
my $file_ens2gn = $ARGV[2];

my %hash;
if($file_ens2gn){
	open  FIN,"$file_ens2gn" or die "can not opne $file_ens2gn";
	while(<FIN>){
		chomp;
		my ($a,$b) = split /\t/,$_;
		$hash{$a} = $b;
	}
	close FIN;
}else{
	$head_2 = "circRNA_ID\tchr\tcircRNA_start\tcircRNA_end\t#junction_reads\tSM_MS_SMS\t#non_junction_reads\tjunction_reads_ratio\tcircRNA_type\tstrand\n";
}

open FIN,"<$file_in"  or die "can not open $file_in";
open FOU,">$file_out" or die "can not open $file_out";
print FOU "$head_2";
while(<FIN>){
	chomp;
	if(/^circRNA_ID/){
		next;
	}
	my @p = split /\t/,$_;
	pop @p;
	my $strand = pop @p;
	my $ens_tmp = pop @p;
	$ens_tmp =~ s/,$//;
	if($file_ens2gn){
		my @X = split /,/,$ens_tmp;
		my @Y;
		foreach my $x(@X){
			if(exists $hash{$x}){
				push @Y,$hash{$x};
			}
		}
		print FOU join("\t",@p),"\t",join(";",@X),"\t",join(";",@Y),"\t",$strand,"\n";
	}else{
		print FOU join("\t",@p),"\t",$strand,"\n";
	}
}
close FIN;
close FOU;
