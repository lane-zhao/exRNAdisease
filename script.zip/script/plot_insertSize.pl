#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;
use Getopt::Long;
use Time::Local;
my %opts;
GetOptions (\%opts,
	"input=s", 
	"prefix=s",
	"outdir=s",
	"help!",
);

my $program = basename($0);
my $usage = <<"USAGE";
  Program : $program
  Discription: saturation2plot.pl
  Usage: perl $program [options]
    -input*    inner_distance_freq.txt
    -prefix    prefix name, default is 'sample'
    -outdir    output dir, default is ./
  example:perl $0
USAGE

die $usage if ( !$opts{input} || $opts{help} );

$opts{outdir} ||= "./";
$opts{prefix} ||= "sample";

my @x = ();
my @y = ();

open FIN,$opts{input} or die "can not open $opts{input}!";
while(<FIN>){
	chomp;
	my ($a,$b,$c) = split /\t/,$_;
	push @x, ($a+$b)/2+300;
	push @y, $c;
}
close FIN;

my @legend;
open (RSCRIPT,">$opts{outdir}/$opts{prefix}.insertSize.R") ||die "Can not open insertSize.R\n";
print RSCRIPT "pdf(\"$opts{outdir}/$opts{prefix}.insertSize.pdf\")\n";
print RSCRIPT "fragsize=rep(c(".join(",",@x)."),times=c(".join(",",@y)."))\n";
print RSCRIPT "frag_sd = format(sd(fragsize), digits=2)\n";
print RSCRIPT "frag_mean = format(mean(fragsize), digits=2)\n";
print RSCRIPT "frag_median = format(median(fragsize), digits=2)\n";
print RSCRIPT "hist(fragsize,probability=T,breaks=100,xlab='RNA fragment size (bp)',main=paste0('$opts{prefix} RNA fragmet size\n', paste(c('Mean=',frag_mean,'; ','SD=',frag_sd),collapse='')),border='blue')"."\n";
print RSCRIPT "lines(density(fragsize,bw=10),col='red')"."\n";
print RSCRIPT "dev.off()"."\n";
close RSCRIPT;

process_cmd("Rscript $opts{outdir}/$opts{prefix}.insertSize.R");
process_cmd("convert $opts{outdir}/$opts{prefix}.insertSize.pdf -append -flatten $opts{outdir}/$opts{prefix}.insertSize.png");

sub process_cmd {
    my ($cmd) = @_;
    print "CMD: $cmd\n";
    my $ret = system($cmd);
    if ($ret){
        die "Error, cmd: $cmd died with ret ($ret) ";
    }
    return;
}


