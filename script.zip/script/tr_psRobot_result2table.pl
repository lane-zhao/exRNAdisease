#!/usr/bin/perl -w
unless(@ARGV==2){die "Usage: perl $0 <psRobot_input> <output_table>\n";}
open IN,$ARGV[0];
open OUT,">$ARGV[1]";
$/ = ">";
<IN> ;
print OUT "query\ttarget\tscore\tquery_start\tquery_end\ttarget_start\ttarget_end\tquery_seq\talign\ttarget_seq\n";
#print OUT "miRNA\tTarget_transcript\tScore\tAlignment\n";
	while (my $ma=<IN>){
	my @all = split /\n/,$ma;
	my @name_score = split /\t/,$all[0];
	my @name_query = split /\s+/,$name_score[0];
	my @name_target = split /\s+/,$name_score[2];
	my $target_id = shift @name_target;
#	my $descript;
#		if(@name_target){$descript = join (" ",@name_target); }
#		else {$descript = "-";}
	my @score = split /\: /,$name_score[1];
	my @query = split /\s+/,$all[2];
	my @sbjct = split /\s+/,$all[4];
	my @align =split /\s+/,$all[3];
	print OUT "$name_query[0]\t$target_id\t$score[1]\t$query[1]\t$query[3]\t$sbjct[3]\t$sbjct[1]\t$query[2]\t$align[1]\t$sbjct[2]\n";
#	print OUT "$name_query[0]\t$target_id\t$score[1]\t$align[1]\n";
}
close IN;
close OUT; 
