#!/usr/bin/env perl
use strict;
use warnings;
use File::Basename;
use Getopt::Long;
use Time::Local;
my %opts;
GetOptions (\%opts,
	"input=s", 
	"prefix=s",
	"outdir=s",
	"help!",
);

my $program = basename($0);
my $usage = <<"USAGE";
  Program : $program
  Discription: saturation2plot.pl
  Usage: perl $program [options]
    -input*   .geneBodyCoverage.r
    -prefix    prefix name, default is 'sample'
    -outdir    output dir, default is './'
  example:perl $0
USAGE

die $usage if ( !$opts{input} || $opts{help} );

$opts{outdir} ||= "./";
$opts{prefix} ||= "sample";

open (FIN,"<$opts{input}") || die "Can not open $opts{input}\n";
my $info = <FIN>; chomp($info);
$info =~ /<- (.+)$/;
$info = "y <- $1";
close FIN;

open  FOUT,">$opts{outdir}/$opts{prefix}.geneBodyCoverage.R" || die "Can not open $opts{outdir}/$opts{prefix}.geneBodyCoverage.R !\n";
print FOUT "$info\n";
print FOUT "\n";
print FOUT "pdf(\"$opts{outdir}/$opts{prefix}.geneBodyCoverage.pdf\")"."\n";
print FOUT "x=1:100"."\n";
print FOUT "icolor = colorRampPalette(c('#7fc97f','#beaed4','#fdc086','#ffff99','#386cb0','#f0027f'))(1)"."\n";
print FOUT "plot(x,y,type='l',xlab=\"Gene body percentile (5'->3')\", ylab='Coverage', main='$opts{prefix} geneBody coverage', lwd=1, col=icolor[1])"."\n";
print FOUT "dev.off()"."\n";
close FOUT;

process_cmd("Rscript $opts{outdir}/$opts{prefix}.geneBodyCoverage.R");
process_cmd("convert $opts{outdir}/$opts{prefix}.geneBodyCoverage.pdf -append -flatten $opts{outdir}/$opts{prefix}.geneBodyCoverage.png");

sub process_cmd {
    my ($cmd) = @_;
    print "CMD: $cmd\n";
    my $ret = system($cmd);
    if ($ret){
        die "Error, cmd: $cmd died with ret ($ret) ";
    }
    return;
}
