#!/usr/bin/env perl
use strict;
use warnings;

my $fasta = $ARGV[0];
open FIN,"$fasta" or die "can not open $fasta!\n";
my $chr = "";
my %info;
while(my $line = <FIN>){
	chomp($line);
	if($line =~ /^>(.+)$/){
		my @tt = split /\s/,$1;
		$chr = $tt[0];
	}else{
		$info{$chr}{LEN_A} += length($line);
		my $xx = $line;
		$xx =~ s/n//g;
		$xx =~ s/N//g;
		$info{$chr}{LEN_rN} += length($xx);
	}
}
close FIN;

open FOUT,">$fasta.hdrs" or die "can not open $fasta.hdrs";
foreach my $c(sort keys %info){
	print FOUT ">$c /len=$info{$c}{LEN_A} /nonNlen=$info{$c}{LEN_rN} /org=species\n";
}
close FOUT;
