#!/usr/bin/perl -w
use strict;
@ARGV==4 || die "
	# Usage:   perl $0 [sample.ciri.txt] [lib_size] [outdir] [sample_name]
	# contact: guantao.zheng\@gmail.com
	# updata:  2018-11-20
";

my $ciri_res = $ARGV[0];
my $lib_size = $ARGV[1];
my $outdir   = $ARGV[2];
my $sample   = $ARGV[3];

system("mkdir -p $outdir");

#stat SRPBM
open F1,"<$ciri_res";
open F2,">$outdir/$sample.count.txt";
open F3,">$outdir/$sample.srpbm.txt";
print F2 "circRNA_id\tcount\n";
print F3 "circRNA_id\tsrpbm\n";
<F1>;
while (<F1>){
	chomp;
	my @line=split /\t/;
	my $ciri_id  = $line[0];
	my $read_num = $line[4];
#	pop @reads;
	print F2 $ciri_id,"\t",(2*$read_num),"\n";
	print F3 $ciri_id,"\t",(2*$read_num)/((2*$lib_size)/1000000000)/150,"\n";
}
close F1;
close F2;
close F3;
